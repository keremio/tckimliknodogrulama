function TCKN()
{
var TCKN = Number(document.getElementById("tckn").value);
var digits = (""+TCKN).split("").map(Number);
var odd = digits[0] + digits[2] + digits[4] + digits[6] + digits[8];
var even = digits[1] + digits[3] + digits[5] + digits[7];
if ((7*odd - even)% 10 == digits[9] && (odd + even + digits[9])%10 == digits[10])
{
  document.getElementById("comment").innerText = " geçerlidir.";
  if(TCKN == 10000000146)
  document.getElementById("comment").innerText = " Gazi Mustafa Kemal Atatürk'e aittir.";
  document.getElementById("comment").style.fontWeight = 'bold';
  
}
else{
  document.getElementById("comment").innerText = " geçersizdir.";
}
}